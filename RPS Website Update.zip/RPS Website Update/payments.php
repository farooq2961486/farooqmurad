<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JazzCash Account</title>
    <link rel="stylesheet" href="styles/payments.css"> 
    <script src="formValidation.js" defer></script> 
</head>
<body>
    <div class="account-box">
        <div class="logo">
            <img src="images/jazzcash logo.png" alt="JazzCash Logo">
        </div>
        <div class="account-details">
            <p class="account-number">JazzCash Account Number: <strong>+923078113098</strong></p>
            <p class="account-holder">Account Holder: <strong>Farooq Murad</strong></p>
        </div>
    </div>
    <div class="account-box">
        <div class="logo">
            <img src="images/easypaisa logo.png" alt="Easypaisa Logo">
        </div>
        <div class="account-details">
            <p class="account-number">Easypaisa Account Number: <strong>+923146106877</strong></p>
            <p class="account-holder">Account Holder: <strong>Farooq Murad</strong></p>
        </div>
    </div>
    <div class="account-box">
        <div class="logo">
            <img src="images/HBL logo.png" alt="HBL Logo">
        </div>
        <div class="account-details">
            <p class="account-number">HBL Account Number: <strong>000098230000</strong></p>
            <p class="account-holder">Account Holder: <strong>Farooq Murad</strong></p>
        </div>
    </div>
    <div class="account-box">
        <form action="submit_payment.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="transactionId">Transaction ID:</label>
                <input type="text" class="form-control" id="transactionId" name="transactionId" placeholder="Enter Transaction ID">
            </div>
            <div class="form-group">
                <label for="screenshot">Screenshot:</label>
                <input type="file" class="form-control-file" id="screenshot" name="screenshot">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>
</html>
