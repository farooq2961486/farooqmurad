<?php
include 'config.php';
if(isset($_REQUEST['submit'])){
if(($_REQUEST['email']=="")||($_REQUEST['confirm_password']==""))
	{
		echo "<small>Fill al Fields...</small>";
	}
else
{
	$sql="UPDATE player SET Password=:password where E_mail=:email";
	$result=$conn->prepare($sql);
	$result->bindParam(':email',$email,PDO::PARAM_STR);
	$result->bindParam(':password',$password,PDO::PARAM_STR);

	$email=$_REQUEST['email'];
	$password=$_REQUEST['confirm_password'];
	$result->execute();

	if ($result) {
	echo "<small>Success...</small>";
	unset($result);
	}else{
		echo "<small>Failed...</small>";
	}
}

}


?>