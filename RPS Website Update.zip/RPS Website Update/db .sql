-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2024 at 06:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `Branch_id` int(11) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Zip_code` int(4) NOT NULL,
  `Contact` bigint(10) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Dated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealerships`
--

CREATE TABLE `dealerships` (
  `D_id` int(10) NOT NULL,
  `D_name` varchar(50) NOT NULL,
  `D_email` varchar(50) NOT NULL,
  `D_tell_no` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(256) NOT NULL,
  `requests` varchar(50) NOT NULL,
  `dated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parcel`
--

CREATE TABLE `parcel` (
  `Parcel_Id` int(10) NOT NULL,
  `Track_Id` bigint(10) NOT NULL,
  `S_Name` varchar(50) NOT NULL,
  `S_Addr` varchar(50) NOT NULL,
  `S_Contact` int(10) NOT NULL,
  `R_Name` varchar(50) NOT NULL,
  `R_Addr` varchar(50) NOT NULL,
  `R_Contact` int(10) NOT NULL,
  `Parcel_type` varchar(50) NOT NULL,
  `Weight_kg` int(5) NOT NULL,
  `Price` int(5) NOT NULL,
  `From_branch` varchar(50) NOT NULL,
  `To_branch` varchar(50) NOT NULL,
  `Dispatched_Time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Checkout` varchar(50) NOT NULL,
  `Current_Location` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Staff_Id` int(8) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `DOB` date NOT NULL,
  `DOJ` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Salary` bigint(20) NOT NULL,
  `Mobile_No` bigint(10) NOT NULL,
  `Email_Addr` varchar(256) NOT NULL,
  `Username` varchar(256) NOT NULL,
  `Staff_Password` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Staff_Id`, `Name`, `Gender`, `DOB`, `DOJ`, `Salary`, `Mobile_No`, `Email_Addr`, `Username`, `Staff_Password`) VALUES
(5, 'Ndiliswa Tyobeka', 'Female', '2000-01-20', '2022-07-06 16:02:07', 39999, 726020485, 'ndiliswatyobeka@gmail.com', 'Ndiliswat', 'SA1@123');

-- --------------------------------------------------------

--
-- Table structure for table `track`
--

CREATE TABLE `track` (
  `Id` int(10) NOT NULL,
  `Track_Id` int(9) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Current_Location` varchar(50) NOT NULL,
  `Dated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `screenshot` varchar(255) NOT NULL,
  `transaction_till_id` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`screenshot`, `transaction_till_id`) VALUES
('C:/xampp/htdocs/RPS Website/uploads/easypaisa logo.jpg', NULL),
('C:/xampp/htdocs/RPS Website/uploads/javed pic.png', NULL),
('C:/xampp/htdocs/RPS Website/uploads/55555.png', NULL),
('C:/xampp/htdocs/RPS Website/uploads/managment.png', NULL),
('C:/xampp/htdocs/RPS Website/uploads/managment.png', '52523256565645454'),
('C:/xampp/htdocs/RPS Website/uploads/managment.png', '4564545454545'),
('C:/xampp/htdocs/RPS Website/uploads/55555.png', '21637632836742736'),
('C:/xampp/htdocs/RPS Website/uploads/55555.png', '21637632836742736'),
('C:/xampp/htdocs/RPS Website/uploads/55555.png', '21637632836742736'),
('C:/xampp/htdocs/RPS Website/uploads/55555.png', '21637632836742736'),
('C:/xampp/htdocs/RPS Website/uploads/55555.png', '21637632836742736'),
('C:/xampp/htdocs/RPS Website/uploads/55555.png', '21637632836742736'),
('C:/xampp/htdocs/RPS Website/uploads/55555.png', '21637632836742736'),
('C:/xampp/htdocs/RPS Website/uploads/55555.png', '21637632836742736'),
('C:/xampp/htdocs/RPS Website/uploads/', ''),
('C:/xampp/htdocs/RPS Website/uploads/', ''),
('C:/xampp/htdocs/RPS Website/uploads/', ''),
('C:/xampp/htdocs/RPS Website/uploads/11111111.png', '2121221212'),
('C:/xampp/htdocs/RPS Website/uploads/managment.png', '454545454545'),
('C:/xampp/htdocs/RPS Website/uploads/managment.png', '454545454545'),
('C:/xampp/htdocs/RPS Website/uploads/managment.png', '454545454545'),
('C:/xampp/htdocs/RPS Website/uploads/444444.png', '2254522146632'),
('C:/xampp/htdocs/RPS Website/uploads/managment.png', '454545454545'),
('C:/xampp/htdocs/RPS Website/uploads/55555.png', '2254522146632'),
('C:/xampp/htdocs/RPS Website/uploads/11111111.png', '454545454545'),
('C:/xampp/htdocs/RPS Website/uploads/', ''),
('C:/xampp/htdocs/RPS Website/uploads/', ''),
('C:/xampp/htdocs/RPS Website/uploads/', ''),
('C:/xampp/htdocs/RPS Website/uploads/', ''),
('C:/xampp/htdocs/RPS Website/uploads/', ''),
('C:/xampp/htdocs/RPS Website/uploads/javed pic.png', '454545454545'),
('C:/xampp/htdocs/RPS Website/uploads/', ''),
('C:/xampp/htdocs/RPS Website/uploads/managment.png', '2254522146632'),
('C:/xampp/htdocs/RPS Website/uploads/11111111.png', '454545454545'),
('C:/xampp/htdocs/RPS Website/uploads/11111111.png', '52523256565645454'),
('C:/xampp/htdocs/RPS Website/uploads/managment.png', '2254522146632'),
('C:/xampp/htdocs/RPS Website/uploads/managment.png', '454545454545'),
('C:/xampp/htdocs/RPS Website/uploads/444444.png', '454545454545'),
('C:/xampp/htdocs/RPS Website/uploads/11111111.png', '454545454545'),
('C:/xampp/htdocs/RPS Website/uploads/444444.png', '52523256565645454');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`Branch_id`);

--
-- Indexes for table `dealerships`
--
ALTER TABLE `dealerships`
  ADD PRIMARY KEY (`D_id`);

--
-- Indexes for table `parcel`
--
ALTER TABLE `parcel`
  ADD PRIMARY KEY (`Parcel_Id`),
  ADD UNIQUE KEY `Track_Id` (`Track_Id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`Staff_Id`),
  ADD UNIQUE KEY `username` (`Username`);

--
-- Indexes for table `track`
--
ALTER TABLE `track`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `Branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100328;

--
-- AUTO_INCREMENT for table `dealerships`
--
ALTER TABLE `dealerships`
  MODIFY `D_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `parcel`
--
ALTER TABLE `parcel`
  MODIFY `Parcel_Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `Staff_Id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `track`
--
ALTER TABLE `track`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
