<?php $page = isset($_GET['page']) ? $_GET['page'] : null; ?>
<div class="header" style="width: 97.2%;">
    <div class="wrap">
        <a href="index.php"><img src="images/logo.png" alt="Railway Parcel System Logo"></a>
        <ul>
            <li><a href="index.php" style="<?php if ($page == null) echo 'background-color: rgb(9, 6, 120); color: white;'; ?>"><div id="icon"></div>Dashboard</a></li>
            <li><a href="index.php?page=delivery list" style="<?php if ($page == 'delivery list' || $page == 'single delivery' || $page == 'new order') echo 'background-color: rgb(9, 6, 120); color: white;'; ?>"><div id="icon"></div>Delivery List</a></li>
            <li><a href="index.php?page=payments" style="<?php if ($page == 'payments') echo 'background-color: rgb(9, 6, 120); color: white;'; ?>"><div id="icon"></div>Payments</a></li>
            <li><a href="index.php?page=track deliveries" style="<?php if ($page == 'track deliveries') echo 'background-color: rgb(9, 6, 120); color: white;'; ?>"><div id="icon"></div>Track Deliveries</a></li>
            <li><a href="index.php?page=branch list" style="<?php if ($page == 'branch list' || $page == 'new branch') echo 'background-color: rgb(9, 6, 120); color: white;'; ?>"><div id="icon"></div>Branch List</a></li>
            <li><a href="history.php?page=history" style="<?php if ($page == 'history') echo 'background-color: rgb(9, 6, 120); color: white;'; ?>"><div id="icon"></div>History</a></li>
        </ul>
        <div class="right-links">
            <a href="index.php?page=my account&username=<?php echo $_SESSION['username']?>">My Account (<?php echo $_SESSION['username']?>)</a>
        </div>
        <div class="right-links">
            <a href="index.php?logout='2'" class="logout">Logout</a>
        </div>
    </div>
</div>
