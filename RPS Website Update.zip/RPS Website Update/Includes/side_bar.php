<!-- <div class="header">
    <div class="logo">
        <h1>Railways</h1>
        <h3>Parcel Management System</h3>
    </div>
    <div class="side_bar">
        <h2>Admin Panel</h2>
        <nav>
            <ul>
                <?php $page = isset($_GET['page']) ? $_GET['page'] : null; ?>
                <li><a href="index.php" style="<?php if ($page == null) echo 'background-color: rgb(9, 6, 120); color: white;'; ?>"><div id="icon"></div>Dashboard</a></li>
                <li><a href="index.php?page=delivery list" style="<?php if ($page == 'delivery list' || $page == 'single delivery' || $page == 'new order') echo 'background-color: rgb(9, 6, 120); color: white;'; ?>"><div id="icon"></div>Delivery List</a></li>
                <li><a href="index.php?page=payments" style="<?php if ($page == 'payments') echo 'background-color: rgb(9, 6, 120); color: white;'; ?>"><div id="icon"></div>Payments</a></li>
                <li><a href="index.php?page=track deliveries" style="<?php if ($page == 'track deliveries') echo 'background-color: rgb(9, 6, 120); color: white;'; ?>"><div id="icon"></div>Track Deliveries</a></li>
                <li><a href="index.php?page=branch list" style="<?php if ($page == 'branch list' || $page == 'new branch') echo 'background-color: rgb(9, 6, 120); color: white;'; ?>"><div id="icon"></div>Branch List</a></li>
            </ul>
        </nav>
    </div>
</div> -->