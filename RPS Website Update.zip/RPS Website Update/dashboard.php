<div class="hero" style="background-image: url('images/train_cargo.jpg'); background-repeat: no-repeat;background-size: cover; height: 680px; width: 100%; position: ; margin: 0px;">
    <span style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; color: black; background-color: white; font-weight: bolder;">
        <h1><b>Welcome to Railway Parcel System<b></h1>
        <p><b>Your one-stop solution for managing parcels efficiently<b></p>
    </span>
</div>
<div class="wrap">
    <?php include 'backend/connection.php'?>    
    <div class="dashboard">
        <div class="containers">
            <div class="container" style="background-color:  lightgray; ">
                <h1><?php echo $connection->query("SELECT * FROM parcel")->num_rows; ?></h1>
                <span>Total Orders</span>
            </div>
            <div class="container" style="background-color:  lightgray">
                <h1><?php echo $connection->query("SELECT * FROM parcel WHERE Status='Off to Head Office'")->num_rows; ?></h1>
                <span>Total Off to Head Office</span>
            </div>
            <div class="container" style="background-color:  lightgray">
                <h1><?php echo $connection->query("SELECT * FROM parcel WHERE Status='Assigned to Rider'")->num_rows; ?></h1>
                <span>Total Assigned to Rider</span>
            </div>
            <div class="container" style="background-color:  lightgray;">
                <h1><?php echo $connection->query("SELECT * FROM parcel WHERE Checkout='Not Paid'")->num_rows; ?></h1>
                <span>Total Pending Orders</span>
            </div>
            <div class="container" style="background-color: lightgray;">
                <h1><?php echo $connection->query("SELECT * FROM parcel WHERE Checkout='Paid'")->num_rows; ?></h1>
                <span>Total Processed Orders</span>
            </div>
            <div class="container" style="background-color:  lightgray">
                <h1><?php echo $connection->query("SELECT * FROM parcel WHERE Status='Delivered'")->num_rows; ?></h1>
                <span>Total Delivered Orders</span>
            </div>
            <div class="container" style="background-color:  lightgray">
                <h1><?php echo $connection->query("SELECT * FROM parcel WHERE Status='Returned'")->num_rows; ?></h1>
                <span>Total Returned Orders</span>
            </div>
            <div class="container" style="background-color:  lightgray">
                <h1><?php echo $connection->query("SELECT * FROM parcel WHERE Status='Cancelled'")->num_rows; ?></h1>
                <span>Total Cancelled Orders</span>
            </div>
            <div class="container" style="background-color:  lightgray">
                <a href="index.php?page=track deliveries"><span>Track Orders</span></a>
            </div>
            <div class="container" style="background-color:  lightgray">
                <a href="index.php?page=delivery list"><span>View Deliveries</span></a>
            </div>
        </div>
    </div>
</div>
