function validateForm() {
    var transactionId = document.getElementById("transactionId").value;
    var screenshot = document.getElementById("screenshot").value;

    if (transactionId === "" || screenshot === "") {
        alert("Transaction ID and Screenshot are required.");
        return false;
    }
    return true;
}

document.getElementById('myForm').addEventListener('submit', function(event) {
    event.preventDefault();
    if (validateForm()) {
        var formData = new FormData(this);

        var xhr = new XMLHttpRequest();
        xhr.open('POST', this.action, true);
        xhr.onload = function () {
            if (xhr.status === 200) {
                alert("Transaction successful!");
                window.location.href = 'dashboard.php';
            } else {
                alert('Error: ' + xhr.statusText);
            }
        };
        xhr.onerror = function () {
            alert('Request failed.');
        };
        xhr.send(formData);
    }
});
