<?php
  session_start(); 
  require('backend/check_user_season.php')
?>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboad</title>

	<link rel="stylesheet" type="text/css" href="styles/index.css">
	<link rel="stylesheet" type="text/css" href="styles/top_header.css">
	<link rel="stylesheet" type="text/css" href="styles/header.css">
	<link rel="stylesheet" type="text/css" href="styles/side_bar.css">
	<link rel="stylesheet" type="text/css" href="styles/sub_main.css">
	<!-- screens -->
	
	<link rel="stylesheet" type="text/css" href="styles/dashboard.css">
	<link rel="stylesheet" type="text/css" href="styles/order_list.css">
	<link rel="stylesheet" type="text/css" href="styles/payments.css">
	<link rel="stylesheet" type="text/css" href="styles/track_deliveries.css">
	<link rel="stylesheet" type="text/css" href="styles/branches.css">
	<link rel="stylesheet" type="text/css" href="styles/new_order.css">
	<link rel="stylesheet" type="text/css" href="styles/dealerships.css">
	<link rel="stylesheet" type="text/css" href="styles/single_delivery.css">
	<link rel="stylesheet" type="text/css" href="styles/checkout.css">
	<link rel="stylesheet" type="text/css" href="styles/my_account.css">
	<link rel="stylesheet" type="text/css" href="styles/style1.css">
	
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

	<style type="text/css">
		@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700');

$base-spacing-unit: 24px;
$half-spacing-unit: $base-spacing-unit / 2;

$color-alpha: #1772FF;
$color-form-highlight: #EEEEEE;

*, *:before, *:after {
	box-sizing:border-box;
}

body {
	padding:$base-spacing-unit;
	font-family:'Source Sans Pro', sans-serif;
	margin:0;
}

h1,h2,h3,h4,h5,h6 {
	margin:0;
}

.container {
	max-width: 97%;
	margin-right:auto;
	margin-left:auto;
	display:flex;
	justify-content:center;
	align-items:center;
/*	min-height:100vh;*/
}

.table {
	width:100%;
	border:1px solid $color-form-highlight;
}

.table-header {
	display:flex;
	width:100%;
	background:#000;
	padding:($half-spacing-unit * 1.5) 0;
}

.table-row {
	display:flex;
	width:100%;
	padding:($half-spacing-unit * 1.5) 0;
	
	&:nth-of-type(odd) {
		background:$color-form-highlight;
	}
}

.table-data, .header__item {
	flex: 1 1 20%;
	text-align:center;
	color: black;
}

.header__item {
	text-transform:uppercase;
	font-weight: bold;
	color: whitesmoke;
}

.filter__link {
	color:white;
	text-decoration: none;
	position:relative;
	display:inline-block;
	padding-left:$base-spacing-unit;
	padding-right:$base-spacing-unit;
	
	&::after {
		content:'';
		position:absolute;
		right:-($half-spacing-unit * 1.5);
		color:white;
		font-size:$half-spacing-unit;
		top: 50%;
		transform: translateY(-50%);
	}
	
	&.desc::after {
		content: '(desc)';
	}

	&.asc::after {
		content: '(asc)';
	}
	
}
	</style>


</head>
<body>
	<div style="width:auto; height: auto;" >
		<?php include 'includes/header.php'?>
	</div>
		<div>
			<h2 style="margin-top: 22px; margin-bottom: 20px;">Boking History section </h2>
		</div>
<div class="container">
	
	<div class="table">
		<div class="table-header">
			<div class="header__item ">Sender Name</div>
			<div class="header__item">Sender Address</div>
			<div class="header__item">Sender Contact</div>
			<div class="header__item">Receiver Name</div>
			<div class="header__item">Receiver Address</div>
			<div class="header__item ">Receiver Contact</div>
			<div class="header__item">Parcel Type</div>
			<div class="header__item">Order Weight</div>
			<div class="header__item">From Branch</div>
			<div class="header__item">To Branch</div>
			<div class="header__item ">Current Location</div>
			<div class="header__item">Status</div>
			<div class="header__item">Price</div>
		</div>
    <?php
    	require 'backend/connection.php';
    	$response = @mysqli_query($connection, "SELECT * FROM parcel");
		 ?>
		<?php while($data = mysqli_fetch_array($response)) : ?>

		<div class="table-content">	
			<div class="table-row">		
				<div class="table-data"><?php echo $data['S_Name']?></div>
				<div class="table-data"><?php echo $data['S_Addr']?> </div>
				<div class="table-data"><?php echo $data['S_Contact']?> </div>
				<div class="table-data"><?php echo $data['R_Name']?></div>
				<div class="table-data"><?php echo $data['R_Addr']?> </div>
				<div class="table-data"><?php echo $data['R_Contact']?> </div>
				<div class="table-data"><?php echo $data['Parcel_type']?></div>
				<div class="table-data"><?php echo $data['Weight_kg']?></div>
				<div class="table-data"><?php echo $data['From_branch']?></div>
				<div class="table-data"><?php echo $data['To_branch']?> </div>
				<div class="table-data"><?php echo $data['Current_Location']?> </div>
				<div class="table-data"><?php echo $data['Status']?></div>
				<div class="table-data"><?php echo $data['Price']?></div>
			</div>
		</div>	
	</div>
</div>
<?php endwhile?>
</body>
</html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>