<div class="dealerships">
    <a href="index.php?page=new dealership"><button>New Dealership</button></a>
    <div class="containers">
            <div class="container">
                <div class="info">
                    <h2>Name:</h2>
                    <span>iCourier</span>
                </div>
                <div class="info">
                    <h2>Tell No:</h2>
                    <span>012 445 4578</span>
                </div>
            </div>
    </div>
</div>