<?php 
$dsn="mysql:host=localhost; dbname=sportshub";
$db_user="root";
$db_password="";

try
{
	$conn= new PDO($dsn, $db_user,$db_password);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
}
catch(PDOException $e)
{
	echo"Connection Failed" . $e->getMessage();
}
 ?>
