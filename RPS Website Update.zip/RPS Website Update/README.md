# ideliveries-parcel-management-system.
A system that manages the parcels.
keeps the record of the parcels,
    The sender's info,
    The recipient's info,
    The parcel's info,
    The branch where the parcel was recieed,
    The branch where the parcel is heading to,
    Keeps the record of the parcel's current location
Keeps the record of the available branches of the company,
Keeps the record of the external dealerships registered,
The parcel can be tracked using its reference numbers.
