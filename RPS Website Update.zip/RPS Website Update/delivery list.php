
<div class="order_list">
    <a href="index.php?page=new order"><button>New Order</button></a>
    <div class="containers">
        <?php require 'backend/select_orders.php'; ?>
        <?php if ($response && mysqli_num_rows($response) > 0) : ?>
            <?php while ($data = mysqli_fetch_array($response)) : ?>
                <a href="index.php?page=single delivery&id=<?php echo $data['Parcel_Id']; ?>">
                    <div class="container">
                        <div class="info" style="display: flex; justify-content: space-between; width: 100%;">
                            <h2>Ref:</h2>
                            <span><?php echo $data['Track_Id']; ?></span>
                        </div>
                        <div class="info"  style="display: flex; justify-content: space-between; width: 100%;">
                            <h2>Type:</h2>
                            <span><?php echo $data['Parcel_type']; ?></span>
                        </div>
                        <div class="info"  style="display: flex; justify-content: space-between; width: 100%;">
                            <h2>Amount:</h2>
                            <span>R<?php echo $data['Price']; ?>.00</span>
                        </div>
                        <div class="info">
                            <span class="<?php echo ($data['Checkout'] == 'Paid') ? 'paid' : 'not_paid'; ?>">
                                (<?php echo $data['Checkout']; ?>)
                            </span>
                        </div>
                    </div>
                </a>
            <?php endwhile; ?>
        <?php else : ?>
            <p>No orders found.</p>
        <?php endif; ?>
    </div>
</div>
