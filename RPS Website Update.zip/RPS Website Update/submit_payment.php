<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $transactionId = $_POST['transactionId'];
    $screenshotName = $_FILES['screenshot']['name'];
    $screenshotTmpName = $_FILES['screenshot']['tmp_name'];
    $uploadDirectory = "C:/xampp/htdocs/RPS Website/uploads/";
    $uploadedFilePath = $uploadDirectory . $screenshotName;
    move_uploaded_file($screenshotTmpName, $uploadedFilePath);
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "db";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "INSERT INTO transactions (transaction_till_id, screenshot) VALUES ('$transactionId', '$uploadedFilePath')";
    if ($conn->query($sql) === TRUE) {
        $conn->close();
        echo "<script>alert('Transaction is Successfully'); window.location.href='index.php';</script>";
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
