<?php include 'backend/select_branches.php'?>
<style type="text/css">
    .cont-align{
        justify-content: space-between;
         width: 100%;
    }
    .btn{
        margin: 10px;
        padding: 9px;
        background-color: black;
        
    }
</style>
<div class="branches">
    <a href="index.php?page=new branch"><button>New Branch</button></a>
    <div class="containers" >
            <?php if($response) : ?>
                <?php while($data = mysqli_fetch_array($response)) : ?>
                    <div class="container " style="width: 350px;">
                        <div class="info cont-align">
                            <h2 style="text-align: start;">Branch Code:</h2>
                            <span><?php echo $data['Branch_id']?></span>
                        </div>
                        <div class="info cont-align">
                            <h2>Address</h2>
                            <span><?php echo $data['Address']?></span>
                        </div>
                        <div class="info cont-align">
                            <h2>Tell No:</h2>
                            <span>0<?php echo $data['Contact']?></span>
                        </div>
                        <div class="info cont-align">
                            <h2>E-mail:</h2>
                            <span><?php echo $data['Email']?></span>
                        </div>
                        <div class="info btn">
                            <a style="color: red;"href="delete.php?delete_branch=<?php echo $data['Branch_id']?>">Delete</a>
                        </div>
                    </div>
                <?php endwhile?>
            <?php endif?>
    </div>
</div>